﻿<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=big5">
    <title>echo指令的應用</title>
  </head>
  <body>
    <?php 
echo " echo指令的應用";
echo "<hr>";
echo "也可以包括<font color='#000ff'> HTML </font>標籤";
    ?>
  </body>
</html>
