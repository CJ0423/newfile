﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
  <title>註解指令的應用</title>
  </head>

  <body bgcolor="#FFCCFF">
      <!-- HTML註解指令 -->
      <h1>網頁內容</h1>

    <?php 
      // PHP單行註解程式碼
      echo "<h2>這是顯示的文字</h2>";
      /* 
      PHP多行註解程式碼
      */
      echo "PHP網頁以 Dreamweaver 來編輯很方便!";
    ?>

  </body>
</html>
