﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>定義常數</title>
</head>
<body bgcolor="#FFFFCC">

<?php 
define("PI",3.14159);
$name="張三丰"
echo "<h2>".Surpro."</h2>";

$rad=10;
echo "圓面積=半徑*半徑*圓周率=";
echo PI*$rad*$rad;
echo "<p>";
define("PI",6);
$name="陳大同"
echo "<h2>".Surpro."</h2>";

$rad=10;
echo "圓面積=半徑*半徑*圓周率=";
echo PI*$rad*$rad;

?>

</body>
</html>
