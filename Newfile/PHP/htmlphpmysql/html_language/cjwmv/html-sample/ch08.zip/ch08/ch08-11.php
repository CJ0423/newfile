﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>複合運算子</title>
</head>

<body>
<h2>複合運算子</h2>

<?php 
$a=566;
$b=20;
echo "<font color='blue'>";
echo "\$a=566<br>";
echo "\$b=20</font><br><hr>";

$a += $b;
echo "\$a += \$b 的結果是".$a."<p>";
$b *=5;
echo "\$b *=5 的結果是".$b."<p>";
?>

</body>
</html>
