﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>伺服端的PHP程式</title>
</head>

<body>

<?php 
echo "<h2><font color='purple'>PHP程式所回應的資料</font></h2>";
echo "你的姓名是 : ".$_POST["uname"]."<p>";
echo "你的密碼是 : ".$_POST["upass"]."<p>";
?>

</body>
</html>
