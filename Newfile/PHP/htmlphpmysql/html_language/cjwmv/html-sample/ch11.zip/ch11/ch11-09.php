﻿<?php
$sco=array( 86,75,93,80,55,68,72,70,88,61);  
Echo "陣列資料列印如下：<br>";
  For($x=0;$x<count($sco);$x++)
  {    Echo $sco[$x]." ： ";    }
?>
