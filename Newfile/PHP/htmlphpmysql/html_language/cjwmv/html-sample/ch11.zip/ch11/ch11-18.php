﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<title>array_count_values 函數</title>
</head>
<body>

<?php 
$score =array(70,95,70,60,88,78,95,88,92,100);
//計算陣列各元素出現的次數
print_r(array_count_values($score));
?>

</body>
</html>
