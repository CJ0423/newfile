﻿<?php
   mkdir("C:\\xampp\\htdocs\\110-all\\member");
   mkdir("C:\\xampp\\htdocs\\110-att\\member");
   mkdir("cheng");
?>