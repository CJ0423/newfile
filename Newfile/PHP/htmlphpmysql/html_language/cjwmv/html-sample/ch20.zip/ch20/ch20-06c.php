﻿<?php
   rmdir("C:\\xampp\\htdocs\\110-all\\member");
   rmdir("C:\\xampp\\htdocs\\110-att");
   rmdir("cheng");
?>