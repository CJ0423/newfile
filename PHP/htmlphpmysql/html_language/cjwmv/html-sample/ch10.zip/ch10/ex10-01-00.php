<?php
  for($d=1;$d<=31;$d++)
  {
     echo $d."�@";
  }
?>