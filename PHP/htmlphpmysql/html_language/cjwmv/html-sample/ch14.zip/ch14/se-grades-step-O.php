﻿<html>
  <head>
     <title>
       成績系統
     </title>
  </head>
  <body>
   <center>
    <h1>中職科大成績系統</h1>
   </center>
    請輸入帳號密碼<br>
    <form method="post" action="se-grades-step-A.php">
          帳號：<input type="text" name="idname" value=""><p>
          密碼：<input type="password" name="idpa" value=""><p>
           <input type="submit" name="submit" value="送出">
           <input type="reset" name="reset" value="重填">
</form>

  </body>
</html>